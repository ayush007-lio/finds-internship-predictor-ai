import { createServerFn } from "@tanstack/react-start";
import { parseCSV, runFindS, predict, TARGET } from "@/lib/findS";

export const uploadDataset = createServerFn({ method: "POST" })
  .inputValidator((d: { csv: string }) => d)
  .handler(async ({ data }) => {
    const parsed = parseCSV(data.csv);
    if (!parsed.headers.includes(TARGET)) {
      throw new Error(`Invalid format: missing required column '${TARGET}'`);
    }
    return {
      headers: parsed.headers,
      preview: parsed.rows.slice(0, 5),
      totalRows: parsed.rows.length,
    };
  });

export const generateHypothesis = createServerFn({ method: "POST" })
  .inputValidator((d: { csv: string }) => d)
  .handler(async ({ data }) => {
    const parsed = parseCSV(data.csv);
    return runFindS(parsed);
  });

export const predictInstance = createServerFn({ method: "POST" })
  .inputValidator((d: { csv: string; instance: Record<string, string> }) => d)
  .handler(async ({ data }) => {
    const parsed = parseCSV(data.csv);
    const result = runFindS(parsed);
    return predict(result.attributes, result.finalHypothesis, data.instance);
  });
