// Find-S algorithm implementation (no ML libraries, pure TS)
// Discretizes numeric values into categorical bins so the hypothesis is human-readable.

export type Row = Record<string, string>;
export const TARGET = "placement_status";
export const POSITIVE_LABEL = "Placed";

export interface ParsedCSV {
  headers: string[];
  rows: Row[];
}

export function parseCSV(text: string): ParsedCSV {
  const lines = text
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter((l) => l.length > 0);
  if (lines.length === 0) throw new Error("Dataset is empty");
  const headers = lines[0].split(",").map((h) => h.trim());
  const rows: Row[] = lines.slice(1).map((line) => {
    const cells = line.split(",").map((c) => c.trim());
    const row: Row = {};
    headers.forEach((h, i) => (row[h] = cells[i] ?? ""));
    return row;
  });
  return { headers, rows };
}

// Discretize a single attribute value to a category for hypothesis comparison.
export function discretize(attr: string, value: string): string {
  const num = Number(value);
  if (Number.isNaN(num)) return value; // already categorical
  switch (attr) {
    case "cgpa":
      if (num >= 8.5) return "High";
      if (num >= 7) return "Medium";
      return "Low";
    case "projects_count":
    case "internships_count":
      return String(Math.trunc(num)); // exact integer category
    case "coding_skill_score":
    case "communication_skill_score":
      if (num >= 80) return "Excellent";
      if (num >= 60) return "Good";
      if (num >= 40) return "Average";
      return "Poor";
    default:
      return value;
  }
}

export interface FindSStep {
  iteration: number;
  exampleIndex: number; // 1-based row index in original dataset
  example: string[];
  hypothesisBefore: string[];
  hypothesisAfter: string[];
  note: string;
}

export interface FindSResult {
  attributes: string[];
  finalHypothesis: string[];
  steps: FindSStep[];
  positiveCount: number;
  totalCount: number;
}

export function runFindS(parsed: ParsedCSV): FindSResult {
  const { headers, rows } = parsed;
  if (!headers.includes(TARGET)) {
    throw new Error(`Dataset missing target column '${TARGET}'`);
  }
  if (rows.length === 0) throw new Error("Dataset has no data rows");

  const attributes = headers.filter((h) => h !== TARGET);
  let hypothesis: string[] | null = null; // null = most specific (∅)
  const steps: FindSStep[] = [];
  let iteration = 0;
  let positiveCount = 0;

  rows.forEach((row, idx) => {
    if (row[TARGET] !== POSITIVE_LABEL) return; // ignore negatives
    positiveCount++;
    iteration++;
    const example = attributes.map((a) => discretize(a, row[a]));
    const before = hypothesis ? [...hypothesis] : attributes.map(() => "∅");
    if (!hypothesis) {
      hypothesis = [...example];
      steps.push({
        iteration,
        exampleIndex: idx + 1,
        example,
        hypothesisBefore: before,
        hypothesisAfter: [...hypothesis],
        note: "Initialized hypothesis with first positive example.",
      });
    } else {
      const after = hypothesis.map((h, i) => (h === example[i] ? h : "?"));
      const changed = after.some((v, i) => v !== hypothesis![i]);
      hypothesis = after;
      steps.push({
        iteration,
        exampleIndex: idx + 1,
        example,
        hypothesisBefore: before,
        hypothesisAfter: [...hypothesis],
        note: changed
          ? "Generalized mismatched attributes to '?'."
          : "Example consistent with hypothesis — no change.",
      });
    }
  });

  if (!hypothesis) {
    throw new Error("No positive ('Placed') examples found in dataset");
  }

  return {
    attributes,
    finalHypothesis: hypothesis,
    steps,
    positiveCount,
    totalCount: rows.length,
  };
}

export function predict(
  attributes: string[],
  hypothesis: string[],
  instance: Record<string, string>,
): { eligible: boolean; details: { attr: string; value: string; discretized: string; hypothesis: string; match: boolean }[] } {
  const details = attributes.map((attr, i) => {
    const raw = instance[attr] ?? "";
    const disc = discretize(attr, raw);
    const h = hypothesis[i];
    const match = h === "?" || h === disc;
    return { attr, value: raw, discretized: disc, hypothesis: h, match };
  });
  return { eligible: details.every((d) => d.match), details };
}
