export const SAMPLE_CSV = `cgpa,projects_count,internships_count,coding_skill_score,communication_skill_score,placement_status
8.7,4,2,85,78,Placed
7.2,2,1,65,70,Placed
6.5,1,0,45,55,Not Placed
9.1,5,2,92,88,Placed
7.8,3,1,72,68,Placed
6.0,1,0,40,50,Not Placed
8.9,4,2,88,82,Placed
7.5,2,1,68,72,Placed
5.8,0,0,35,45,Not Placed
8.3,3,2,80,75,Placed
`;
