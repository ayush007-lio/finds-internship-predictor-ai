import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  uploadDataset,
  generateHypothesis,
  predictInstance,
} from "@/server/findSFunctions";
import { SAMPLE_CSV } from "@/lib/sampleDataset";
import { TARGET } from "@/lib/findS";

export const Route = createFileRoute("/")({
  component: Index,
  head: () => ({
    meta: [
      { title: "Find-S Internship Predictor — AI Selection Demo" },
      {
        name: "description",
        content:
          "Upload a CSV, generate a Find-S hypothesis, and predict student internship eligibility step-by-step.",
      },
    ],
  }),
});

interface UploadState {
  csv: string;
  headers: string[];
  preview: Record<string, string>[];
  totalRows: number;
}

interface HypoStep {
  iteration: number;
  exampleIndex: number;
  example: string[];
  hypothesisBefore: string[];
  hypothesisAfter: string[];
  note: string;
}

interface HypoResult {
  attributes: string[];
  finalHypothesis: string[];
  steps: HypoStep[];
  positiveCount: number;
  totalCount: number;
}

interface PredictResult {
  eligible: boolean;
  details: { attr: string; value: string; discretized: string; hypothesis: string; match: boolean }[];
}

function fmtHypothesis(h: string[]) {
  return `< ${h.join(", ")} >`;
}

function Index() {
  const [upload, setUpload] = useState<UploadState | null>(null);
  const [hypo, setHypo] = useState<HypoResult | null>(null);
  const [prediction, setPrediction] = useState<PredictResult | null>(null);
  const [instance, setInstance] = useState<Record<string, string>>({});
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [loading, setLoading] = useState<"upload" | "hypo" | "predict" | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  const inputAttrs = useMemo(
    () => upload?.headers.filter((h) => h !== TARGET) ?? [],
    [upload],
  );

  function clearMessages() {
    setError(null);
    setSuccess(null);
  }

  async function handleCSVText(csv: string) {
    clearMessages();
    setLoading("upload");
    try {
      const res = await uploadDataset({ data: { csv } });
      setUpload({ csv, ...res });
      setHypo(null);
      setPrediction(null);
      setInstance({});
      setSuccess(`Dataset loaded: ${res.totalRows} rows, ${res.headers.length} columns.`);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Failed to load dataset");
    } finally {
      setLoading(null);
    }
  }

  async function handleFile(file: File) {
    const text = await file.text();
    if (!text.trim()) {
      setError("Uploaded file is empty");
      return;
    }
    await handleCSVText(text);
  }

  async function runHypothesis() {
    if (!upload) return;
    clearMessages();
    setLoading("hypo");
    try {
      const res = await generateHypothesis({ data: { csv: upload.csv } });
      setHypo(res);
      setSuccess(`Hypothesis generated from ${res.positiveCount} positive examples.`);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Failed to generate hypothesis");
    } finally {
      setLoading(null);
    }
  }

  async function runPredict() {
    if (!upload) return;
    clearMessages();
    setLoading("predict");
    try {
      const res = await predictInstance({ data: { csv: upload.csv, instance } });
      setPrediction(res);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Prediction failed");
    } finally {
      setLoading(null);
    }
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Hero */}
      <header
        className="border-b"
        style={{ background: "var(--gradient-hero)" }}
      >
        <div className="mx-auto max-w-6xl px-6 py-12 text-brand-foreground">
          <Badge className="mb-4 bg-white/15 text-white hover:bg-white/20 border-0">
            Academic Demo · Machine Learning
          </Badge>
          <h1 className="text-4xl md:text-5xl font-bold tracking-tight">
            AI Internship Selection Predictor
          </h1>
          <p className="mt-3 text-lg text-white/85 max-w-2xl">
            Upload a student dataset, generate a hypothesis using the{" "}
            <span className="font-semibold">Find-S algorithm</span>, and predict whether
            a new candidate is eligible for internship selection.
          </p>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-6 py-10 space-y-8">
        {error && (
          <Alert variant="destructive">
            <AlertTitle>Error</AlertTitle>
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}
        {success && (
          <Alert className="border-success/40 bg-success/10 text-foreground">
            <AlertTitle className="text-success">Success</AlertTitle>
            <AlertDescription>{success}</AlertDescription>
          </Alert>
        )}

        {/* Upload */}
        <Card style={{ background: "var(--gradient-card)", boxShadow: "var(--shadow-soft)" }}>
          <CardHeader>
            <CardTitle>1. Upload Dataset</CardTitle>
            <CardDescription>
              CSV with columns including <code>cgpa, projects_count, internships_count, coding_skill_score, communication_skill_score, placement_status</code>.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div
              className="border-2 border-dashed border-brand/40 rounded-xl p-8 text-center bg-brand/5 hover:bg-brand/10 transition cursor-pointer"
              onClick={() => fileRef.current?.click()}
              onDragOver={(e) => e.preventDefault()}
              onDrop={(e) => {
                e.preventDefault();
                const f = e.dataTransfer.files?.[0];
                if (f) handleFile(f);
              }}
            >
              <p className="font-medium text-foreground">Drop your CSV here or click to browse</p>
              <p className="text-sm text-muted-foreground mt-1">.csv up to a few MB</p>
              <input
                ref={fileRef}
                type="file"
                accept=".csv,text/csv"
                className="hidden"
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  if (f) handleFile(f);
                }}
              />
            </div>
            <div className="flex gap-3 flex-wrap">
              <Button
                variant="outline"
                onClick={() => handleCSVText(SAMPLE_CSV)}
                disabled={loading === "upload"}
              >
                Try Sample Dataset
              </Button>
              {upload && (
                <span className="text-sm text-muted-foreground self-center">
                  Loaded {upload.totalRows} rows · {upload.headers.length} columns
                </span>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Preview */}
        {upload && (
          <Card>
            <CardHeader>
              <CardTitle>2. Dataset Preview</CardTitle>
              <CardDescription>First 5 rows</CardDescription>
            </CardHeader>
            <CardContent className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    {upload.headers.map((h) => (
                      <TableHead key={h}>{h}</TableHead>
                    ))}
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {upload.preview.map((row, i) => (
                    <TableRow key={i}>
                      {upload.headers.map((h) => (
                        <TableCell key={h}>{row[h]}</TableCell>
                      ))}
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        )}

        {/* Algorithm explanation */}
        <Card>
          <CardHeader>
            <CardTitle>About the Find-S Algorithm</CardTitle>
          </CardHeader>
          <CardContent>
            <ol className="list-decimal pl-6 space-y-1 text-sm text-foreground/90">
              <li>Initialize hypothesis <code>h</code> to the most specific (∅, ∅, …).</li>
              <li>Iterate only over <strong>positive</strong> training examples (placement_status = "Placed").</li>
              <li>For each attribute: if it matches <code>h</code>, keep it; if it differs, generalize to <code>?</code>.</li>
              <li>Ignore all negative examples.</li>
              <li>Output the final maximally-specific hypothesis consistent with all positives.</li>
            </ol>
          </CardContent>
        </Card>

        {/* Generate hypothesis */}
        {upload && (
          <Card>
            <CardHeader>
              <CardTitle>3. Generate Hypothesis</CardTitle>
              <CardDescription>
                Numeric values are discretized (e.g. cgpa ≥ 8.5 → "High") so the hypothesis is readable.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <Button onClick={runHypothesis} disabled={loading === "hypo"}>
                {loading === "hypo" ? "Computing..." : "Generate Hypothesis using Find-S"}
              </Button>

              {hypo && (
                <>
                  <div className="rounded-lg border bg-brand/5 p-4">
                    <p className="text-xs uppercase tracking-wide text-muted-foreground mb-1">
                      Final Hypothesis
                    </p>
                    <p className="font-mono text-lg text-brand font-semibold break-all">
                      {fmtHypothesis(hypo.finalHypothesis)}
                    </p>
                    <p className="text-xs text-muted-foreground mt-2">
                      Attributes: {hypo.attributes.join(", ")}
                    </p>
                  </div>

                  <div>
                    <h4 className="font-semibold mb-2">Iteration-wise updates</h4>
                    <div className="overflow-x-auto">
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>#</TableHead>
                            <TableHead>Row</TableHead>
                            <TableHead>Example (discretized)</TableHead>
                            <TableHead>Hypothesis after</TableHead>
                            <TableHead>Note</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {hypo.steps.map((s) => (
                            <TableRow key={s.iteration}>
                              <TableCell>{s.iteration}</TableCell>
                              <TableCell>{s.exampleIndex}</TableCell>
                              <TableCell className="font-mono text-xs">
                                {fmtHypothesis(s.example)}
                              </TableCell>
                              <TableCell className="font-mono text-xs text-brand">
                                {fmtHypothesis(s.hypothesisAfter)}
                              </TableCell>
                              <TableCell className="text-xs text-muted-foreground">
                                {s.note}
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                  </div>
                </>
              )}
            </CardContent>
          </Card>
        )}

        {/* Predict */}
        {upload && hypo && (
          <Card>
            <CardHeader>
              <CardTitle>4. Predict Eligibility</CardTitle>
              <CardDescription>Enter a candidate's attributes:</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {inputAttrs.map((attr) => (
                  <div key={attr} className="space-y-1.5">
                    <Label htmlFor={attr}>{attr}</Label>
                    <Input
                      id={attr}
                      value={instance[attr] ?? ""}
                      onChange={(e) =>
                        setInstance((p) => ({ ...p, [attr]: e.target.value }))
                      }
                      placeholder={`e.g. ${upload.preview[0]?.[attr] ?? ""}`}
                    />
                  </div>
                ))}
              </div>
              <Button
                onClick={runPredict}
                disabled={loading === "predict" || inputAttrs.some((a) => !instance[a])}
              >
                {loading === "predict" ? "Predicting..." : "Predict"}
              </Button>

              {prediction && (
                <div
                  className={`rounded-lg border p-5 ${
                    prediction.eligible
                      ? "bg-success/10 border-success/40"
                      : "bg-destructive/10 border-destructive/40"
                  }`}
                >
                  <p className="text-sm uppercase tracking-wide text-muted-foreground">
                    Result
                  </p>
                  <p
                    className={`text-2xl font-bold ${
                      prediction.eligible ? "text-success" : "text-destructive"
                    }`}
                  >
                    {prediction.eligible ? "✓ Eligible" : "✗ Not Eligible"}
                  </p>
                  <div className="mt-4 overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Attribute</TableHead>
                          <TableHead>Input</TableHead>
                          <TableHead>Discretized</TableHead>
                          <TableHead>Hypothesis</TableHead>
                          <TableHead>Match</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {prediction.details.map((d) => (
                          <TableRow key={d.attr}>
                            <TableCell>{d.attr}</TableCell>
                            <TableCell>{d.value}</TableCell>
                            <TableCell className="font-mono text-xs">{d.discretized}</TableCell>
                            <TableCell className="font-mono text-xs">{d.hypothesis}</TableCell>
                            <TableCell>
                              {d.match ? (
                                <Badge className="bg-success text-success-foreground">✓</Badge>
                              ) : (
                                <Badge variant="destructive">✗</Badge>
                              )}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        )}

        <footer className="text-center text-xs text-muted-foreground py-6">
          Built with TanStack Start · Find-S implemented from scratch (no ML libraries)
        </footer>
      </main>
    </div>
  );
}
